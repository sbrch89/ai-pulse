import { useEffect, useState } from "react";

export default function Home() {
  const [articles, setArticles] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/generate-articles")
      .then((res) => res.json())
      .then((data) => {
        setArticles(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <p>Loading articles...</p>;
  if (!articles) return <p>Failed to load articles.</p>;

  return (
    <div style={{ padding: "20px", fontFamily: "Arial, sans-serif" }}>
      <h1>AI Pulse - مقالات تلقائية</h1>

      <section>
        <h2>الأخبار (Arabic News)</h2>
        {articles.ar.news.map((item, i) => (
          <article key={i}>
            <h3>{item.title}</h3>
            <p>{item.content}</p>
          </article>
        ))}
      </section>

      <section>
        <h2>News (English)</h2>
        {articles.en.news.map((item, i) => (
          <article key={i}>
            <h3>{item.title}</h3>
            <p>{item.content}</p>
          </article>
        ))}
      </section>
    </div>
  );
}